jQuery(document).ready(function() {


jQuery('div.arfwr_id').each(function(){
var name= jQuery(this).data('name');
var effectype= jQuery(this).data('type');
 function makeresponsive()
{
    var w=jQuery(window).width();
    var count=jQuery('#'+name+' .arfwr_item').length;
    var t_w;
  if((w > 1100))
  {
    t_w=96/count;
    jQuery('#'+name+' .arfwr_item').css({'width':t_w+'%'});
  }
 if((w < 1100) && (w > 769))
  {
    t_w=96/count;
    jQuery('#'+name+' .arfwr_item').css({'width':t_w+'%'});
  }

  if((w < 768) && (w > 451))
  {
    t_w=90/count;
    jQuery('#'+name+' .arfwr_item').css({'width':t_w+'%'});
  }
    if(w < 450)
  {
    t_w=88/count;
    jQuery('#'+name+' .arfwr_item').css({'width':t_w+'%'});
  }

}

makeresponsive();
jQuery(window).resize(makeresponsive);
     jQuery('#'+name+' .arfwr_item').css({'display' : 'inline-block'});
           var width=jQuery('#'+name+' .arfwr_item').width();
        var count=jQuery('#'+name+' .arfwr_item').length;
        var containerwidth=100*count;
      jQuery('#'+name+' .arfwr_container').css({'width':containerwidth+'%'});
if(effectype=='fade')
{
 var items = (Math.floor(Math.random() * (jQuery('#'+name+' .arfwr_item').length)));
	jQuery('#'+name+' .arfwr_item').hide().eq(items).show();
   function next(){
      jQuery('#'+name+' div.arfwr_item:visible').delay(5000).fadeOut('slow',function(){
      jQuery(this).appendTo('#'+name+' .arfwr_container');
   	jQuery('#'+name+' div.arfwr_item:first').fadeIn('slow',next);
    });
   }

   next();

 }
 if(effectype=='slide')
 {

      setInterval(function() {
            jQuery('#'+name+' .arfwr_container').animate({"left": -100+'%'},1000, function(){
                // to create infinite loop
                jQuery('#'+name+' .arfwr_container').css('left',0).append( jQuery('#'+name+' .arfwr_item:first'));
            });
        }, 5000);
 }

 setTimeout(function(){
 	jQuery.ajax({
		type: "POST",                 // use $_POST request to submit data
		url: arfwr_ajax_url.ajax_url,      // URL to "wp-admin/admin-ajax.php"
		data: {
			action     : 'arfwreviews', // wp_ajax_*, wp_ajax_nopriv_*
            security : arfwr_ajax_url.check_nonce,
            load_count : jQuery('#'+name+' div.arfwr_id').data('count'),
            load_orderby : jQuery('#'+name+' div.arfwr_id').data('orderby'),
            load_sort : jQuery('#'+name+' div.arfwr_id').data('sort'),
            load_attribs : jQuery('#'+name+' div.arfwr_id').data('attribs'),
            load_cats : jQuery('#'+name+' div.arfwr_id').data('cats'),
            load_authors : jQuery('#'+name+' div.arfwr_id').data('authors'),
            load_tags : jQuery('#'+name+' div.arfwr_id').data('tags')
		},
		success:function( data ) {
		  jQuery('#'+name+' .arfwr_container').append( data ); //
          jQuery('#'+name+' .arfwr_item').css({'display' : 'inline-block'}); 
          newcount=jQuery('#'+name+' .arfwr_item').length;
        var newwidth=100*newcount;
      jQuery('#'+name+' .arfwr_container').css({'width':newwidth+'%'});
          makeresponsive();
		},
		error: function(){
			console.log(errorThrown); // error
		}
	});



 },3000);


 });

});